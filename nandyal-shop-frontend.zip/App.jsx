import { useState, useEffect } from "react";

function App() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);

  useEffect(() => {
    fetch("https://nandyal-shop-backend.onrender.com/products")
      .then((res) => res.json())
      .then(setProducts);
  }, []);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Nandyal Shopping</h1>
      <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
        {products.map((p) => (
          <div key={p.id} style={{ border: "1px solid #ccc", padding: 10 }}>
            <img src={p.image} width="100" alt={p.name} />
            <h2>{p.name}</h2>
            <p>₹{p.price}</p>
            <button onClick={() => addToCart(p)}>Add to Cart</button>
          </div>
        ))}
      </div>
      <h2>Cart</h2>
      {cart.map((c, i) => (
        <div key={i}>
          {c.name} - ₹{c.price}
        </div>
      ))}
    </div>
  );
}

export default App;